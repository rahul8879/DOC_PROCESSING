import React, { useState } from 'react';
import { Form, Button, Spinner, Row, Col, Card, Alert, Table } from 'react-bootstrap';
import axios from 'axios';

const KYCUpload = ({ selectedKycType, setKycData, kycData, setSelectedFile, selectedFile }) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [validationResult, setValidationResult] = useState(null);
  const [confidenceScore, setConfidenceScore] = useState(null);

  // Store the actual file object, not the blob URL
  const handleFileChange = (event) => {
    setSelectedFile(event.target.files[0]);  // Set the actual file object
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!selectedFile) {
      setError('Please upload an image.');
      return;
    }
    setError(null);
    setLoading(true);

    const formData = new FormData();
    formData.append('file', selectedFile);  // Append the file directly

    try {
      const response = await axios.post('http://localhost:8000/extract-kyc-info/', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      const { data } = response.data;

      // Set extracted KYC data, validation results, and confidence score
      setKycData(data.extracted_data);
      setValidationResult(data.document_validation);
      setConfidenceScore(data.ocr_confidence);

    } catch (e) {
      setError('Failed to extract KYC data. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Card className="shadow-sm border-light rounded">
        <Card.Header className="text-center" style={{ backgroundColor: '#00338d', color: '#ffffff', padding: '10px 0' }}>
          <h5>Upload {selectedKycType} for Extraction</h5>
        </Card.Header>
        <Card.Body>
          <Form onSubmit={handleSubmit}>
            <Form.Group controlId="formFile" className="mb-3">
              <Form.Label>Upload {selectedKycType} Image</Form.Label>
              <Form.Control type="file" onChange={handleFileChange} className="small-file-input" />
            </Form.Group>
            {error && <Alert variant="danger" className="text-center small-alert">{error}</Alert>}
            <div className="text-center">
              <Button 
                type="submit" 
                variant="primary" 
                disabled={loading} 
                className="small-btn"
                style={{ backgroundColor: '#ffb600', borderColor: '#ffb600', padding: '5px 20px' }}
              >
                {loading ? <Spinner as="span" animation="border" size="sm" /> : 'Extract Data'}
              </Button>
            </div>
          </Form>

          {/* Display uploaded image and extracted data */}
          {selectedFile && kycData && (
            <Row className="mt-4">
              <Col md={4}>
                <Card className="shadow-sm">
                  <Card.Body>
                    <h6>Uploaded Image</h6>
                    <img src={URL.createObjectURL(selectedFile)} alt="KYC Document" style={{ width: '100%', borderRadius: '5px' }} />
                  </Card.Body>
                </Card>
              </Col>
              <Col md={8}>
                <h6>Extracted Information</h6>

                {/* Validation results */}
                {validationResult && (
                  <Alert variant={validationResult.valid ? "success" : "danger"}>
                    {validationResult.valid 
                      ? `Valid ${validationResult.document_type} (Confidence: ${validationResult.confidence * 100}%)`
                      : `Invalid Document (Confidence: ${validationResult.confidence * 100}%)`
                    }
                  </Alert>
                )}

                {/* Confidence score */}
                {confidenceScore && (
                  <p><strong>OCR Confidence Score:</strong> {confidenceScore}%</p>
                )}

                <Table responsive bordered>
                  <thead>
                    <tr>
                      <th>Field</th>
                      <th>Extracted Value</th>
                      <th>Matched</th>
                      <th>Confidence</th>
                      <th>Edit</th>
                    </tr>
                  </thead>
                  <tbody>
                    {Object.keys(kycData).map((key, index) => (
                      <tr key={index}>
                        <td>{key}</td>
                        <td>{kycData[key]}</td>
                        <td>
                          {/* You can add your logic for matching here */}
                          <i className="bi bi-check-circle-fill" style={{ color: 'green' }}></i>
                        </td>
                        <td>
                          {/* Assuming all confidences are 95% for example */}
                          95%
                        </td>
                        <td>
                          <Button size="sm" variant="outline-secondary">Edit</Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </Table>
              </Col>
            </Row>
          )}
        </Card.Body>
      </Card>
    </>
  );
};

export default KYCUpload;
