import React from 'react';
import { Navbar, Container } from 'react-bootstrap';

const Header = () => {
  return (
    <Navbar bg="dark" variant="dark" expand="lg" className="mb-5">
      <Container>
        <Navbar.Brand href="#home" style={{ color: '#ffb600' }}>Document AI - Admin Portal</Navbar.Brand>
      </Container>
    </Navbar>
  );
};

export default Header;
