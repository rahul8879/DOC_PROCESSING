import React, { useState } from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import Header from './Header';
import Sidebar from './Sidebar';
import KYCUpload from './KYCUpload';
import 'bootstrap/dist/css/bootstrap.min.css';

const AdminPortal = () => {
  const [selectedKycType, setSelectedKycType] = useState('Passport'); // Default KYC Type
  const [kycData, setKycData] = useState(null);
  const [selectedFile, setSelectedFile] = useState(null);

  return (
    <>
     
      <Container fluid>
        <Row>
          {/* Sidebar Section */}
          <Col md={3} className="bg-light">
            <Sidebar selectedKycType={selectedKycType} setSelectedKycType={setSelectedKycType} />
          </Col>

          {/* Main Upload and Data Section */}
          <Col md={9}>
            <KYCUpload 
              selectedKycType={selectedKycType} 
              setKycData={setKycData} 
              kycData={kycData} 
              setSelectedFile={setSelectedFile} 
              selectedFile={selectedFile}
            />
          </Col>
        </Row>
      </Container>
    </>
  );
};

export default AdminPortal;
