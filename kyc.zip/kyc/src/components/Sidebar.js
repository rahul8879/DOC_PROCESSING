import React from 'react';
import { ListGroup } from 'react-bootstrap';
import './Sidebar.css'; // Custom styling

const Sidebar = ({ selectedKycType, setSelectedKycType }) => {
  return (
    <div className="sidebar d-flex flex-column p-3" style={{ minHeight: '100vh', backgroundColor: '#f8f9fa', boxShadow: '2px 0 5px rgba(0,0,0,0.1)' }}>
      
      {/* Branding Section */}
      <div className="branding text-center mb-2" style={{ marginBottom: '10px' }}>
      
        <h4 className="brand-name" style={{ color: '#00338d', fontWeight: 'bold', marginBottom: '0' }}>kycAI</h4>
        <p className="brand-tagline" style={{ fontSize: '13px', color: '#555', marginTop: '5px' }}>by RAHUL</p>
      </div>
      
      {/* Separator */}
      <div className="separator mb-3" style={{ borderBottom: '1px solid #ccc', marginBottom: '10px' }}></div>
      
      {/* KYC Type Selection */}
      <div className="kyc-selection">
        <h5 style={{ color: '#00338d', fontWeight: 'bold', marginBottom: '15px' }}>Select KYC Type</h5>
        <ListGroup variant="flush">
          <ListGroup.Item 
            action 
            active={selectedKycType === 'Retail KYC'} 
            onClick={() => setSelectedKycType('Retail KYC')}
            style={{ cursor: 'pointer', color: selectedKycType === 'Retail KYC' ? '#fff' : '#00338d', backgroundColor: selectedKycType === 'Retail KYC' ? '#00338d' : '#fff' }}
          >
            Retail KYC
          </ListGroup.Item>
          <ListGroup.Item 
            action 
            active={selectedKycType === 'Commercial KYC'} 
            onClick={() => setSelectedKycType('Commercial KYC')}
            style={{ cursor: 'pointer', color: selectedKycType === 'Commercial KYC' ? '#fff' : '#00338d', backgroundColor: selectedKycType === 'Commercial KYC' ? '#00338d' : '#fff' }}
          >
            Commercial KYC
          </ListGroup.Item>
        </ListGroup>
      </div>
    </div>
  );
};

export default Sidebar;
