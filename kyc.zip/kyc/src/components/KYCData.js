import React from 'react';
import { Card } from 'react-bootstrap';

const KYCData = ({ kycData }) => {
  return (
    <Card className="border-0">
      <Card.Body>
        <h5 className="text-center" style={{ color: '#00338d' }}>Extracted KYC Details</h5>
        <ul className="list-group list-group-flush">
          <li className="list-group-item"><strong>Legal Name:</strong> {kycData['Legal Name']}</li>
          <li className="list-group-item"><strong>Date of Birth:</strong> {kycData['Date of Birth']}</li>
          <li className="list-group-item"><strong>Nationality:</strong> {kycData['Nationality']}</li>
          <li className="list-group-item"><strong>Residential Address:</strong> {kycData['Residential Address']}</li>
          <li className="list-group-item"><strong>Unique Identification Number:</strong> {kycData['Unique Identification Number']}</li>
        </ul>
      </Card.Body>
    </Card>
  );
};

export default KYCData;
